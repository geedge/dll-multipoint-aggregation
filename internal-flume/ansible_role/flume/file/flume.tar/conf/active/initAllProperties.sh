#!/bin/bash
sed -i 's@machine1@'"${MACHINE1}"'@g' *.properties
sed -i 's@machine2@'"${MACHINE2}"'@g' *.properties
sed -i 's@machine3@'"${MACHINE3}"'@g' *.properties
sed -i 's@machine4@'"${MACHINE4}"'@g' *.properties
sed -i 's@machine5@'"${MACHINE5}"'@g' *.properties
sed -i 's@machine6@'"${MACHINE6}"'@g' *.properties
sed -i 's@machine7@'"${MACHINE7}"'@g' *.properties
sed -i 's@machine8@'"${MACHINE8}"'@g' *.properties
sed -i 's@machine9@'"${MACHINE9}"'@g' *.properties
sed -i 's@machine_10@'"${MACHINE10}"'@g' *.properties
sed -i 's@machine_11@'"${MACHINE11}"'@g' *.properties
sed -i 's@machine_12@'"${MACHINE12}"'@g' *.properties
sed -i 's@machine_13@'"${MACHINE13}"'@g' *.properties


sed -i 's@kafka_addr@'"${KAFKA_ADDR}"'@g' *.properties


