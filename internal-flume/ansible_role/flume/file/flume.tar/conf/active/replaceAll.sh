#!/bin/bash

sed -i 's/192.168.60.101/machine1/g' *.properties
sed -i 's/192.168.60.102/machine2/g' *.properties
sed -i 's/192.168.60.103/machine3/g' *.properties
sed -i 's/192.168.60.104/machine4/g' *.properties
sed -i 's/192.168.60.105/machine5/g' *.properties
sed -i 's/192.168.60.106/machine6/g' *.properties
sed -i 's/192.168.60.107/machine7/g' *.properties
sed -i 's/192.168.60.108/machine8/g' *.properties
sed -i 's/192.168.60.109/machine9/g' *.properties
sed -i 's/machine10/machine_10/g' *.properties
sed -i 's/machine11/machine_11/g' *.properties
sed -i 's/machine12/machine_12/g' *.properties
sed -i 's/machine13/machine_13/g' *.properties


sed -i 's/CONNECTION-RECORD-LOG/CONNECTION-RECORD-COMPLETED-LOG/g' *.properties


sed -i 's/192.168.1.3:9093/kafka_addr/g' *.properties
